import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { Product } from '../model/product';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent implements OnInit{
  title : string ;
  listProducts : Product [] = [];
  constructor(){

  }
ngOnInit(){
   this.title = "This is Product Page"
   this.listProducts = [
  { id: 1, name: "Laptop", price: 1200, description: "High performance laptop" },
  { id: 2, name: "Phone", price: 800, description: "Latest smartphone with great camera" },
  { id: 3, name: "Tablet", price: 600, description: "Lightweight tablet for daily use" },
  { id: 4, name: "Headphones", price: 150, description: "Noise-cancelling wireless headphones" }
];

}
}
